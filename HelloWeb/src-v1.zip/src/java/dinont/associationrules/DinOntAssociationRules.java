/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dinont.associationrules;


import com.rapidminer.Process;
import com.rapidminer.RapidMiner;
import com.rapidminer.RapidMiner.ExecutionMode;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.operator.IOContainer;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.tools.XMLException;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import dinont.associationrules.Concepts;
import dinont.utilities.Database;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import seks.basic.ontology.OntologyInteractionImpl;


/**
 *
 * @author Luis
 */
public class DinOntAssociationRules {
    private static Process rm5;
    private static String fileXML = "F:\\Dissertacao\\FrontEnd\\processXML\\process5.XML";
    private String results = "";
    private String resultsconcepts = "";
    private String resultsToDatabase = "false";

    
    public DinOntAssociationRules()
    {
        results = "";
        resultsconcepts = "";
        resultsToDatabase = "false";
    }
    
    
    public void rapidminerInit()
    {
        RapidMiner.setExecutionMode(ExecutionMode.COMMAND_LINE);
        RapidMiner.init();
    }
    
    // Original name is processResults() - It's working, do not mess with it.
    
    public void processResults()
    {
        try {
            rm5 = new Process(new File(fileXML));
            
			IOContainer ioResult = rm5.run();
            ExampleSet resultSet;
            int num_rules =0;
            if (ioResult.getElementAt(0) instanceof ExampleSet) {
                resultSet = (ExampleSet)ioResult.getElementAt(0);
                for (int i=0; i<=resultSet.size()-1; i++){
                  if ( ( resultSet.getExample(i).get("Premise Items").equals(1)) && (resultSet.getExample(i).get("Conclusion Items").equals(1)) )
                  {
                    num_rules ++;
                    results += "<ul><li title=\"Premise\">"+resultSet.getExample(i).get("Premise")+"</li>"
                            +"<li title=\"Conclusion\">"+ resultSet.getExample(i).get("Conclusion")+"</li>"
                            +"<li title=\"Confidence\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Confidence"))+"</li>"
                    +"<li title=\"Conviction\" class=\"metrics\">";
                            
                    if ( resultSet.getExample(i).get("Conviction").equals("Infinity") )
                      results += resultSet.getExample(i).get("Conviction");
                    else
                      results += String.format("%f%n",resultSet.getExample(i).get("Conviction"));
                    
                    results += "</li>"
                    +"<li title=\"Gain\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Gain"))+"</li>"
                    +"<li title=\"Laplace\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Laplace"))+"</li>"
                    +"<li title=\"Lift\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Lift"))+"</li>"
                    +"<li title=\"Ps\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Ps"))+"</li>"
                    +"<li title=\"Total Support\" class=\"metrics\">"+ String.format("%f%n", resultSet.getExample(i).get("Total Support"))+"</li><li class=\"num_rules\">"+num_rules+"</li></ul>";
                  }
                  else
                    break;
                }
            }
            else
              results = "No results found.";
            
            results = results.replace("[", "");
            results = results.replace("]", "");
            
            
        } catch (OperatorException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XMLException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void processResultsConcepts() 
    {
      Concepts cp = new Concepts();
      OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
      HashMap <String, ArrayList<String>> hmConcepts = new HashMap<String, ArrayList<String>>();
      HashMap <String, ArrayList<String>> levelCandidate = new HashMap<String, ArrayList<String>>();
      ArrayList <String> ngramsList = new ArrayList<String> ();
      ArrayList <String> premiseWordList = new ArrayList<String> ();
      ArrayList <String> conclusionWordList = new ArrayList<String> ();
      String premiseWord, premiseWordString, premiseWordOriginal;
      String conclusionWord, conclusionWordString, conclusionWordOriginal;
      boolean ngramsFlag = true;
      boolean ngramsNoMatchFoundFlag = false;
      int ngramsDistance = 0;
      
        try {
            rm5 = new Process(new File(fileXML));
            
			IOContainer ioResult = rm5.run();
            ExampleSet resultSet;
            int num_rules =0;
            if (ioResult.getElementAt(0) instanceof ExampleSet) {
                resultSet = (ExampleSet)ioResult.getElementAt(0);
                for (int i=0; i<=resultSet.size()-1; i++){
                  if ( ( resultSet.getExample(i).get("Premise Items").equals(1)) && (resultSet.getExample(i).get("Conclusion Items").equals(1)) )
                  {
                    num_rules ++;
// ------------------------------------- Premise words finding
                    premiseWord = ""+resultSet.getExample(i).get("Premise");
                    premiseWord = premiseWord.replace("[", "");
                    premiseWord = premiseWord.replace("]", "");
                    premiseWordOriginal = premiseWord;
                    
                    ngramsFlag = true; // If ngramsFlag is true, then it found exact matches, otherwise false
                    ngramsNoMatchFoundFlag = false; // If no match found, it turns to true
                    ngramsList = cp.getNgramList(premiseWord);
                    if (ngramsList.size() == 0){  // If the premise word did not found any exact match within the ontology, tries others
                      ngramsFlag = false;
                      ngramsList = cp.getOnegramCandidatesList(premiseWord);
                      
                    }
                    
                    hmConcepts = cp.getConceptsRelated(ngramsList);
                    
                    
                    premiseWordString = "<p>"+premiseWordOriginal+"</p><select>";
                    
                    if (ngramsFlag)
                      premiseWordString = "<p>"+premiseWordOriginal+"</p><select>";
                    if (!ngramsFlag)
                      premiseWordString = "<p>"+premiseWordOriginal+" (exact match not found)</p>Candidates:"+"<select>";
                    
                    for (int j=0; j<hmConcepts.size(); j++){
                      // System.out.println("For ("+premiseWord+")-> Concepts:"+hmConcepts.get(unigramsList.get(j)));
                      if (!hmConcepts.get(ngramsList.get(j)).equals(""))
                      {
                        ngramsDistance = 0;
                        
                        if (!ngramsFlag){
                          ngramsDistance = cp.getNGramWordCount(ngramsList.get(j))-1;
                        }
                        
                        String ngramsMatchColorClass = cp.getClassColorConceptsName(ngramsDistance);

                        System.out.println("("+num_rules+") ngrams distance is "+ngramsDistance+". ngram found-"+ngramsList.get(j)+". Class color="+ngramsMatchColorClass);
                        
                        premiseWordList = hmConcepts.get(ngramsList.get(j));
                        
                        for (int m=0; m<premiseWordList.size(); m++){
                          System.out.println("("+num_rules+") PremiseList"+m+":"+premiseWordList.get(m)+";");
                          premiseWord = premiseWordList.get(m);
                          System.out.println("("+num_rules+") PremiseWordString: "+premiseWordString+"\n premiseWord:"+premiseWord);
                          if (!premiseWordString.contains(premiseWord)){
                                
                              if (ngramsFlag)
                                premiseWordString = premiseWordString+"<option class=\""+ngramsMatchColorClass+"\" value=\""+premiseWord+"\">"+premiseWord+" ("+ngramsDistance+")"+"</option>";
                              if (!ngramsFlag)
                                premiseWordString += "<option class=\""+ngramsMatchColorClass+"\" value=\""+premiseWord+"\">"+premiseWord+" ("+ngramsDistance+")"+"</option>";
                              
                            }
                            
                        }
                      }
                      else {
                        ngramsNoMatchFoundFlag = true;
                      }
                    }
                    premiseWordString = premiseWordString+"</select>";
                    if (ngramsNoMatchFoundFlag){
                     premiseWordString = "<p>"+premiseWordOriginal+"</p>"+"<select><option>(Empty)</option></select>";
                    }
                    
                    
// -------------------------------------
// ------------------------------------- Conclusion words finding
                    conclusionWord = ""+resultSet.getExample(i).get("Conclusion");
                    conclusionWord = conclusionWord.replace("[", "");
                    conclusionWord = conclusionWord.replace("]", "");
                    conclusionWordOriginal = conclusionWord;

                    ngramsList = cp.getNgramList(conclusionWord);
                    hmConcepts = cp.getConceptsRelated(ngramsList);
                    conclusionWordString = "<p>"+conclusionWordOriginal+"</p>"+"<select class=\"matchClass0\">";
                    for (int j=0; j<hmConcepts.size(); j++){
                      //System.out.println("For ("+conclusionWord+")-> Concepts:"+hmConcepts.get(unigramsList.get(j)));
                      if (!hmConcepts.get(ngramsList.get(j)).equals("")){
                       conclusionWord = ""+hmConcepts.get(ngramsList.get(j));
                       //conclusionWordList = cp.processWord(conclusionWord, ", ");
                        conclusionWordList = hmConcepts.get(ngramsList.get(j));
                        for (int m=0; m<conclusionWordList.size(); m++){
                          System.out.println("("+num_rules+") ConclusionList"+m+":"+conclusionWordList.get(m)+";");
                          conclusionWord = conclusionWordList.get(m);
                          System.out.println("("+num_rules+") ConclusionWordString: "+conclusionWordString+"\n conclusionWord:"+conclusionWord);
                          if (!conclusionWordString.contains(conclusionWord))
                            conclusionWordString = conclusionWordString+"<option value=\""+conclusionWord+"\">"+conclusionWord+"</option>";
                        }
                      }
                    }
                    conclusionWordString = conclusionWordString+"</select>";
                    if (conclusionWordString.contains("<select></select>"))
                      conclusionWordString = "<p>"+conclusionWordOriginal+"</p>"+"<select><option>(Empty)</option></select>";
 // -------------------------------------
                    
                    resultsconcepts += "<ul><li title=\"Premise\">"+premiseWordString+"</li>"
                            +"<li title=\"Conclusion\">"+ conclusionWordString+"</li>"
                            +"<li title=\"Confidence\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Confidence"))+"</li>"
                    +"<li title=\"Conviction\" class=\"metrics\">";
                            
                    if ( resultSet.getExample(i).get("Conviction").equals("Infinity") )
                      resultsconcepts += resultSet.getExample(i).get("Conviction");
                    else
                      resultsconcepts += String.format("%f%n",resultSet.getExample(i).get("Conviction"));
                    
                    resultsconcepts += "</li>"
                    +"<li title=\"Gain\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Gain"))+"</li>"
                    +"<li title=\"Laplace\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Laplace"))+"</li>"
                    +"<li title=\"Lift\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Lift"))+"</li>"
                    +"<li title=\"Ps\" class=\"metrics\">"+ String.format("%f%n",resultSet.getExample(i).get("Ps"))+"</li>"
                    +"<li title=\"Total Support\" class=\"metrics\">"+ String.format("%f%n", resultSet.getExample(i).get("Total Support"))+"</li><li class=\"num_rules\">"+num_rules+"</li></ul>";
                  }
                  else
                    break;
                }
            }
            else
              resultsconcepts = "No results found.";
            
            resultsconcepts = resultsconcepts.replace("[", "");
            resultsconcepts = resultsconcepts.replace("]", "");
            
            
        } catch (OperatorException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XMLException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void processResultsToDatabase()
    {
      String conclusionTMP, premiseTMP;
      Object premise, conclusion, confidence, conviction, laplace, gain, lift, ps, totalSupport;
      Database dbRules = new Database();
      Connection con = dbRules.databaseConnect("jdbc:mysql://localhost:3306/mydb", "root", "", "com.mysql.jdbc.Driver");

      boolean databaseDeleteAllRecordsFromTable = dbRules.databaseDeleteAllRecordsFromTable(con, "rules_stemmed");
      
        try {
            rm5 = new Process(new File(fileXML));
            
			IOContainer ioResult = rm5.run();
            ExampleSet resultSet;

            if (ioResult.getElementAt(0) instanceof ExampleSet) {
                resultSet = (ExampleSet)ioResult.getElementAt(0);
                for (int i=0; i<=resultSet.size()-1; i++){
                  if ( ( resultSet.getExample(i).get("Premise Items").equals(1)) && (resultSet.getExample(i).get("Conclusion Items").equals(1)) )
                  {
                    resultsToDatabase = "false";
                    premiseTMP = (String)resultSet.getExample(i).get("Premise");
                    premiseTMP = premiseTMP.replace("]", "");
                    premise = premiseTMP.replace("[", "");
                    
                    
                    conclusionTMP = (String)resultSet.getExample(i).get("Conclusion");
                    conclusionTMP = conclusionTMP.replace("[", "");
                    conclusion = conclusionTMP.replace("]", "");

                    confidence = resultSet.getExample(i).get("Confidence");
                    conviction = resultSet.getExample(i).get("Conviction");
                    
                    if ( conviction.toString().contains("Infinity") )
                      conviction = 8888;
                    
                    gain = resultSet.getExample(i).get("Gain");
                    laplace = resultSet.getExample(i).get("Laplace");
                    lift = resultSet.getExample(i).get("Lift");
                    ps = resultSet.getExample(i).get("Ps");
                    totalSupport = resultSet.getExample(i).get("Total Support");

                    ArrayList<String> ruleArray = new ArrayList<String>();
                    ruleArray.add(0, "");
                    ruleArray.add(1, premise.toString());
                    ruleArray.add(2, conclusion.toString());
                    ruleArray.add(3, conviction.toString());
                    ruleArray.add(4, gain.toString());
                    ruleArray.add(5, lift.toString());
                    ruleArray.add(6, laplace.toString());
                    ruleArray.add(7, ps.toString());
                    ruleArray.add(8, totalSupport.toString());
                    ruleArray.add(9, confidence.toString());
    
                    dbRules.databaseInsertRule(con, ruleArray);
                  
                    resultsToDatabase = "true";
                  }
                  else
                    break;
                }
            }
            
            
            
        } catch (OperatorException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (XMLException ex) {
            Logger.getLogger(DinOntAssociationRules.class.getName()).log(Level.SEVERE, null, ex);
        }
        dbRules.databaseDisconnect(con);
    }
    
    public void processResultsFromDatabase()
    {
      // Variable initiation section -----------------------
      Concepts cp = new Concepts();
      Object premise, conclusion, confidence, conviction, laplace, gain, lift, ps, totalSupport;
      Database dbRules = new Database();
      Connection con = dbRules.databaseConnect("jdbc:mysql://localhost:3306/mydb", "root", "", "com.mysql.jdbc.Driver");

      HashMap <String, ArrayList<String>> hmConcepts = new HashMap<String, ArrayList<String>>();
      HashMap <Integer, ArrayList<String>> rulesHM = new HashMap <Integer, ArrayList<String>>();
      ArrayList <String> ngramsList;
      ArrayList<String> premiseWordList, conclusionWordList;

      boolean ngramsMatchFlag, ngramsNoMatchFoundFlag;

      String premiseWordOriginal, premiseWordString, conclusionWordOriginal, conclusionWordString;
      Integer ngramsDistance;
      
      rulesHM = dbRules.databaseGetRules(con);
      
      if (!rulesHM.isEmpty()) {
        for (int i=0; i<=rulesHM.size()-1; i++){

// ------------------------------------- Premise words finding
          premise = rulesHM.get(i+1).get(0);
                    
          premiseWordOriginal = premise.toString();
          
          ngramsMatchFlag = true; // If ngramsFlag is true, then it found exact matches, otherwise false
          ngramsNoMatchFoundFlag = false; // If no match found, it turns to true
          ngramsList = cp.getNgramList(premise.toString());
          
          if (ngramsList.isEmpty()){  // If the premise word did not found any exact match within the ontology, tries others
            ngramsMatchFlag = false;
            ngramsList = cp.getOnegramCandidatesList(premise.toString());
            if (ngramsList.isEmpty()){
              ngramsNoMatchFoundFlag = true;
            }
          }
          
          // Get here with a ngram list of match or candidates match ngrams
          
          hmConcepts = cp.getConceptsRelated(ngramsList);
                    
          if (ngramsMatchFlag)
            premiseWordString = "<p>"+premiseWordOriginal+"</p><select>";
          else {
            premiseWordString = "<p>"+premiseWordOriginal+" (exact match not found) Candidates:</p><select>";
          }    
          for (int j=0; j<hmConcepts.size(); j++){
            if (!hmConcepts.get(ngramsList.get(j)).isEmpty())
            {
              ngramsDistance = 0;

              if (!ngramsMatchFlag){
                ngramsDistance = cp.getNGramWordCount(ngramsList.get(j))-1;
              }

              String ngramsMatchColorClass = cp.getClassColorConceptsName(ngramsDistance);

              System.out.println("("+(i+1)+") ngrams distance is "+ngramsDistance+". ngram found-"+ngramsList.get(j)+". Class color="+ngramsMatchColorClass);

              premiseWordList = hmConcepts.get(ngramsList.get(j));

              for (int m=0; m<premiseWordList.size(); m++){
                System.out.println("("+(i+1)+") PremiseList"+m+":"+premiseWordList.get(m)+";");
                premise = premiseWordList.get(m);
                System.out.println("("+(i+1)+") PremiseWordString: "+premiseWordString+"\n premise:"+premise);
                if (!premiseWordString.contains(premise.toString())){
                    if (ngramsMatchFlag)
                      premiseWordString = premiseWordString+"<option class=\""+ngramsMatchColorClass+"\" value=\""+premise+"\">"+premise+" ("+ngramsDistance+")"+"</option>";
                    else
                      premiseWordString += "<option class=\""+ngramsMatchColorClass+"\" value=\""+premise+"\">"+premise+" ("+ngramsDistance+")"+"</option>";
                  }
              }
            }
            else {
              ngramsNoMatchFoundFlag = true;
            }
          }
          premiseWordString = premiseWordString+"</select>";
          if (ngramsNoMatchFoundFlag){
              premiseWordString = "<p>"+premiseWordOriginal+"</p><select><option>(Empty)</option></select>";
          }
          System.out.println("("+(i+1)+")premiseWordString: "+premiseWordString);
                    
// -------------------------------------  End of Premise words finding        

// -------------------------------------  Conclusion words finding        
          
          conclusion = rulesHM.get(i+1).get(1);
          conclusionWordOriginal = conclusion.toString();
          ngramsList = cp.getNgramList(conclusion.toString());
          
          ngramsMatchFlag = true; // If ngramsFlag is true, then it found exact matches, otherwise false
          ngramsNoMatchFoundFlag = false; // If no match found, it turns to true
          
          if (ngramsList.isEmpty()){  // If the premise word did not found any exact match within the ontology, tries others
            ngramsMatchFlag = false;
            ngramsList = cp.getOnegramCandidatesList(conclusion.toString());
            if (ngramsList.isEmpty()){
              ngramsNoMatchFoundFlag = true;
            }
          }
          
          hmConcepts = cp.getConceptsRelated(ngramsList);
                    
          if (ngramsMatchFlag)
            conclusionWordString = "<p>"+conclusionWordOriginal+"</p><select>";
          else {
            conclusionWordString = "<p>"+conclusionWordOriginal+" (exact match not found) Candidates:</p><select>";
          }    
          for (int j=0; j<hmConcepts.size(); j++){
            if (!hmConcepts.get(ngramsList.get(j)).isEmpty())
            {
              ngramsDistance = 0;

              if (!ngramsMatchFlag){
                ngramsDistance = cp.getNGramWordCount(ngramsList.get(j))-1;
              }

              String ngramsMatchColorClass = cp.getClassColorConceptsName(ngramsDistance);

              System.out.println("("+(i+1)+") ngrams distance is "+ngramsDistance+". ngram found-"+ngramsList.get(j)+". Class color="+ngramsMatchColorClass);

              conclusionWordList = hmConcepts.get(ngramsList.get(j));

              for (int m=0; m<conclusionWordList.size(); m++){
                System.out.println("("+(i+1)+") conclusionList"+m+":"+conclusionWordList.get(m)+";");
                conclusion = conclusionWordList.get(m);
                System.out.println("("+(i+1)+") conclusionWordString: "+conclusionWordString+"\n conclusion:"+conclusion);
                if (!conclusionWordString.contains(conclusion.toString())){
                    if (ngramsMatchFlag)
                      conclusionWordString = conclusionWordString+"<option class=\""+ngramsMatchColorClass+"\" value=\""+conclusion+"\">"+conclusion+" ("+ngramsDistance+")"+"</option>";
                    else
                      conclusionWordString += "<option class=\""+ngramsMatchColorClass+"\" value=\""+conclusion+"\">"+conclusion+" ("+ngramsDistance+")"+"</option>";
                  }
              }
            }
            else {
              ngramsNoMatchFoundFlag = true;
            }
          }
          conclusionWordString = conclusionWordString+"</select>";
          if (ngramsNoMatchFoundFlag){
              conclusionWordString = "<p>"+conclusionWordOriginal+"</p><select><option>(Empty)</option></select>";
          }
          System.out.println("("+(i+1)+")conclusionWordString: "+conclusionWordString);
          
// -------------------------------------  End of Conclusion words finding 
          
          conviction = rulesHM.get(i+1).get(2);
          gain = rulesHM.get(i+1).get(3);
          lift = rulesHM.get(i+1).get(4);
          laplace = rulesHM.get(i+1).get(5);
          ps = rulesHM.get(i+1).get(6);
          totalSupport = rulesHM.get(i+1).get(7);
          confidence = rulesHM.get(i+1).get(8);
          
          // HTML Vector construction 
          System.out.println("("+(i+1)+")"+"conviction:"+conviction+"-gain:"+gain+"-lift:"+lift+"-laplace:"+laplace+"-ps:"+ps+"-total Support:"+totalSupport+"-confidence:"+confidence);
          
          resultsconcepts += "<ul><li title=\"Premise\">"+premiseWordString+"</li>"
                          +"<li title=\"Conclusion\">"+ conclusionWordString+"</li>"
                          +"<li title=\"Confidence\" class=\"metrics\">"+ confidence+"</li>"
                          +"<li title=\"Conviction\" class=\"metrics\">";
                            
          if ( conviction.toString().contains("8888") )
            resultsconcepts += "Infinity";
          else
            resultsconcepts += conviction;
                    
          resultsconcepts += "</li>"
                          +"<li title=\"Gain\" class=\"metrics\">"+ gain+"</li>"
                          +"<li title=\"Laplace\" class=\"metrics\">"+ laplace+"</li>"
                          +"<li title=\"Lift\" class=\"metrics\">"+ lift+"</li>"
                          +"<li title=\"Ps\" class=\"metrics\">"+ ps+"</li>"
                          +"<li title=\"Total Support\" class=\"metrics\">"+ totalSupport+"</li><li class=\"num_rules\">"+(i+1)+"</li></ul>";
                    
        }
      }
      else
        System.out.println("There are no rules in database.");
      
      dbRules.databaseDisconnect(con);
    }
    
    public void processResultsFromDatabaseV2()
    {
      // Variable initiation section -----------------------
      Concepts cp = new Concepts();
      Object premise, conclusion, confidence, conviction, laplace, gain, lift, ps, totalSupport;
      Database dbRules = new Database();
      Connection con = dbRules.databaseConnect("jdbc:mysql://localhost:3306/mydb", "root", "", "com.mysql.jdbc.Driver");

      HashMap <String, ArrayList<String>> hmConcepts = new HashMap<String, ArrayList<String>>();
      HashMap <String, ArrayList<String>> ngramsListHM = new HashMap<String, ArrayList<String>>();
      HashMap <Integer, ArrayList<String>> rulesHM = new HashMap <Integer, ArrayList<String>>();
      ArrayList <String> levelsNameList = new ArrayList<String> ();
      HashMap <String, String> levelsNamePercentageHM = new HashMap<String, String>();

      Calendar cal = Calendar.getInstance(); 
      SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

      ArrayList <String> ngramsList, premiseWordList, conclusionWordList;
      levelsNameList.add("level0");
      levelsNameList.add("level1");
      levelsNameList.add("level2");
      levelsNameList.add("level3");
      levelsNameList.add("level4");
      levelsNameList.add("level5");
      levelsNamePercentageHM.put("level0", "100%");
      levelsNamePercentageHM.put("level1", "80%");
      levelsNamePercentageHM.put("level2", "60%");
      levelsNamePercentageHM.put("level3", "40%");
      levelsNamePercentageHM.put("level4", "20%");
      levelsNamePercentageHM.put("level5", "5%");

      
      boolean ngramsMatchFlag, ngramsNoMatchFoundFlag;

      String premiseWordOriginal, premiseWordString, conclusionWordOriginal, conclusionWordString;
      Integer ngramsDistance, ngramsPercentage, ngramsWordCount;
      String premiseWord;
      
      File file = new File("F:\\Dissertacao\\FrontEnd\\DARprocessResultsFromDatabaseV2log.txt");  
      FileOutputStream fis;  
      try {
        fis = new FileOutputStream(file);
        PrintStream out = new PrintStream(fis);  
        System.setOut(out);  
      } catch (FileNotFoundException ex) {
        Logger.getLogger(Concepts.class.getName()).log(Level.SEVERE, null, ex);
      }
      cal.getTime(); 
      System.out.println("["+sdf.format(cal.getTime())+"]");
      
      rulesHM = dbRules.databaseGetRules(con);
      
      if (!rulesHM.isEmpty()) {
        for (int i=0; i<=rulesHM.size()-1; i++){
          System.out.println("("+(i+1)+")"+" Start: Premise <"+rulesHM.get(i+1).get(0)+"> Conclusion <"+rulesHM.get(i+1).get(1)+">");
// ------------------------------------- Premise words finding
          premise = rulesHM.get(i+1).get(0);
                    
          premiseWordOriginal = premise.toString();
          premiseWordString = "<p>"+premiseWordOriginal;
          
          ngramsMatchFlag = true; // If ngramsFlag is true, then it found exact matches, otherwise false
          ngramsNoMatchFoundFlag = false; // If no match found, it turns to true
                    
          ngramsWordCount = cp.processWord(premise.toString(), "_").size();
          
          ngramsList = cp.getNgramList(premise.toString());
          
          // --------------------
          
          /*if (!ngramsList.isEmpty()){
           * ngramsListHM =
           * Double wordCosSim = cp.getCosineSimilarity(ngramsList, ngramsList);
           * }*/          
          
          
          
          // --------------------
          
          
          if (ngramsList.isEmpty()){  // If the premise word did not found any exact match within the ontology, tries others
            premiseWordString += " (exact match not found) Candidates:</p><select>";
            switch (ngramsWordCount) {
              case 1:{
                ngramsListHM = cp.getOnegramCandidatesListV2(premise.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=1; m<=ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              premiseWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") premiseWordList - "+premiseWordList);
                              for (int m2=0; m2<premiseWordList.size(); m2++) {
                                if (!premiseWordString.contains(premiseWordList.get(m2))){
                                  premiseWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+premiseWordList.get(m2)+"\">"+premiseWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+premise.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                                  
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    premiseWordString += "</select>";
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+premise.toString());
                  premiseWordString += "<option>(Empty)</option></select>";
                }
                break;
              }
              case 2:{
                ngramsListHM = cp.getBigramCandidatesList(premise.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=0; m<ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              premiseWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") premiseWordList - "+premiseWordList);
                              for (int m2=0; m2<premiseWordList.size(); m2++) {
                                if (!premiseWordString.contains(premiseWordList.get(m2))){
                                  premiseWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+premiseWordList.get(m2)+"\">"+premiseWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+premise.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    premiseWordString += "</select>";
                    
                    
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+premise.toString());
                  premiseWordString += "<option>(Empty)</option></select>";
                }
                break;
              }
              case 3:{
                // ngramsList = cp.getTrigramCandidatesList (premise.toString());
                break;
              }
            }
            if (ngramsList.isEmpty()){
              ngramsNoMatchFoundFlag = true;
            }
          }
          else {
            // 100% - Found exact matches
            premiseWordString += "</p><select>";
            ngramsPercentage = 100;
            hmConcepts = cp.getConceptsRelated(ngramsList);
              for (int i2=0; i2<hmConcepts.size(); i2++){
                premiseWordList = hmConcepts.get(ngramsList.get(i2));
                for (int j2=0; j2<premiseWordList.size(); j2++) {
                  if (!premiseWordString.contains(premiseWordList.get(j2)))
                    premiseWordString += "<option class=\"level0\" value=\""+premiseWordList.get(j2)+"\">"+premiseWordList.get(j2)+" ("+levelsNamePercentageHM.get("level0")+")</option>";
                }
              }

              // 1
              if (ngramsWordCount == 1) {
                ngramsListHM = cp.getOnegramCandidatesListV2(premise.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=1; m<=ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              premiseWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") premiseWordList - "+premiseWordList);
                              for (int m2=0; m2<premiseWordList.size(); m2++) {
                                if (!premiseWordString.contains(premiseWordList.get(m2))){
                                  premiseWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+premiseWordList.get(m2)+"\">"+premiseWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+premise.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(premise.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    // premiseWordString += "</select>";
                    
                    
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+premise.toString());
                  premiseWordString += "<option>(Empty)</option></select>";
                }
              } else if (ngramsWordCount == 2) {
                ngramsListHM = cp.getBigramCandidatesList(premise.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=0; m<ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              premiseWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") premiseWordList - "+premiseWordList);
                              for (int m2=0; m2<premiseWordList.size(); m2++) {
                                if (!premiseWordString.contains(premiseWordList.get(m2)))
                                  premiseWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+premiseWordList.get(m2)+"\">"+premiseWordList.get(m2)+" ("+levelsNamePercentageHM.get(levelsNameList.get(m))+")</option>";
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                        }
                    }
                    //premiseWordString += "</select>";
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+premise.toString());
                  premiseWordString += "<option>(Empty)</option>";
                }
              }
              premiseWordString += "</select>";
          }

          System.out.println("("+(i+1)+")premiseWordString: "+premiseWordString);
                    
// -------------------------------------  End of Premise words finding        

          
// -------------------------------------  Conclusion words finding        
          conclusion = rulesHM.get(i+1).get(1);
                    
          conclusionWordOriginal = conclusion.toString();
          conclusionWordString = "<p>"+conclusionWordOriginal;
          
          ngramsMatchFlag = true; // If ngramsFlag is true, then it found exact matches, otherwise false
          ngramsNoMatchFoundFlag = false; // If no match found, it turns to true
                    
          ngramsWordCount = cp.processWord(conclusion.toString(), "_").size();
          
          ngramsList = cp.getNgramList(conclusion.toString());
          
          if (ngramsList.isEmpty()){  // If the conclusion word did not found any exact match within the ontology, tries others
            conclusionWordString += " (exact match not found) Candidates:</p><select>";
            switch (ngramsWordCount) {
              case 1:{
                ngramsListHM = cp.getOnegramCandidatesListV2(conclusion.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=1; m<=ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              conclusionWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") conclusionWordList - "+conclusionWordList);
                              for (int m2=0; m2<conclusionWordList.size(); m2++) {
                                if (!conclusionWordString.contains(conclusionWordList.get(m2))){
                                  conclusionWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+conclusionWordList.get(m2)+"\">"+conclusionWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+conclusion.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                                  
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    conclusionWordString += "</select>";
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+conclusion.toString());
                  conclusionWordString += "<option>(Empty)</option></select>";
                }
                break;
              }
              case 2:{
                ngramsListHM = cp.getBigramCandidatesList(conclusion.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=0; m<ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              conclusionWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") conclusionWordList - "+conclusionWordList);
                              for (int m2=0; m2<conclusionWordList.size(); m2++) {
                                if (!conclusionWordString.contains(conclusionWordList.get(m2))){
                                  conclusionWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+conclusionWordList.get(m2)+"\">"+conclusionWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+conclusion.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    conclusionWordString += "</select>";
                    
                    
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+conclusion.toString());
                  conclusionWordString += "<option>(Empty)</option></select>";
                }
                break;
              }
              case 3:{
                // ngramsList = cp.getTrigramCandidatesList (conclusion.toString());
                break;
              }
            }
            if (ngramsList.isEmpty()){
              ngramsNoMatchFoundFlag = true;
            }
          }
          else {
            // 100% - Found exact matches
            conclusionWordString += "</p><select>";
            ngramsPercentage = 100;
            hmConcepts = cp.getConceptsRelated(ngramsList);
              for (int i2=0; i2<hmConcepts.size(); i2++){
                conclusionWordList = hmConcepts.get(ngramsList.get(i2));
                for (int j2=0; j2<conclusionWordList.size(); j2++) {
                  if (!conclusionWordString.contains(conclusionWordList.get(j2)))
                    conclusionWordString += "<option class=\"level0\" value=\""+conclusionWordList.get(j2)+"\">"+conclusionWordList.get(j2)+" ("+levelsNamePercentageHM.get("level0")+")</option>";
                }
              }

              // 1
              if (ngramsWordCount == 1) {
                ngramsListHM = cp.getOnegramCandidatesListV2(conclusion.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=1; m<=ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              conclusionWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") conclusionWordList - "+conclusionWordList);
                              for (int m2=0; m2<conclusionWordList.size(); m2++) {
                                if (!conclusionWordString.contains(conclusionWordList.get(m2))){
                                  conclusionWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+conclusionWordList.get(m2)+"\">"+conclusionWordList.get(m2)+" ("+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%)</option>";
                                  System.out.println("("+(i+1)+") Common words Cosine similarity:" + "<"+conclusion.toString()+"><"+cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(m2), " ")+"> = "+"«"+cp.getCosineSimilarity(cp.processWord(conclusion.toString(), "_"), cp.processWord(ngramsListHM.get(levelsNameList.get(m)).get(n), " "))*100+"%»");
                                }
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                          
                        }
                                        
                    }
                    // conclusionWordString += "</select>";
                    
                    
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+conclusion.toString());
                  conclusionWordString += "<option>(Empty)</option></select>";
                }
              } else if (ngramsWordCount == 2) {
                ngramsListHM = cp.getBigramCandidatesList(conclusion.toString());
                // Gets "level1" and "level2" arrayLists
                if (!ngramsListHM.isEmpty()){
                    for (int m=0; m<ngramsListHM.size(); m++) {
                        if (!ngramsListHM.get(levelsNameList.get(m)).isEmpty()){
                          hmConcepts = cp.getConceptsRelated(ngramsListHM.get(levelsNameList.get(m)));

                          for (int n=0; n<hmConcepts.size(); n++) {
                            if (!hmConcepts.isEmpty()){
                              conclusionWordList = hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)).get(n));
                              System.out.println("("+(i+1)+")"+"Showing "+ngramsListHM.get(levelsNameList.get(m)).size()+" candidates ("+hmConcepts.get(ngramsListHM.get(levelsNameList.get(m)))+") conclusionWordList - "+conclusionWordList);
                              for (int m2=0; m2<conclusionWordList.size(); m2++) {
                                if (!conclusionWordString.contains(conclusionWordList.get(m2)))
                                  conclusionWordString += "<option class=\""+levelsNameList.get(m)+"\" value=\""+conclusionWordList.get(m2)+"\">"+conclusionWordList.get(m2)+" ("+levelsNamePercentageHM.get(levelsNameList.get(m))+")</option>";
                              }
                              
                            }
                          }
                        }
                        else {
                          System.out.println("("+(i+1)+")"+"No candidates found for ->"+ngramsListHM.get(m));
                        }
                    }
                    //conclusionWordString += "</select>";
                }
                else{
                  System.out.println("("+(i+1)+")"+"No Candidates Found for - "+conclusion.toString());
                  conclusionWordString += "<option>(Empty)</option>";
                }
              }
              conclusionWordString += "</select>";
          }

          System.out.println("("+(i+1)+")conclusionWordString: "+conclusionWordString);
          
// -------------------------------------  End of Conclusion words finding        
          
          
          
          conviction = rulesHM.get(i+1).get(2);
          gain = rulesHM.get(i+1).get(3);
          lift = rulesHM.get(i+1).get(4);
          laplace = rulesHM.get(i+1).get(5);
          ps = rulesHM.get(i+1).get(6);
          totalSupport = rulesHM.get(i+1).get(7);
          confidence = rulesHM.get(i+1).get(8);
          
          // HTML Vector construction 
          System.out.println("("+(i+1)+")"+"conviction:"+conviction+"-gain:"+gain+"-lift:"+lift+"-laplace:"+laplace+"-ps:"+ps+"-total Support:"+totalSupport+"-confidence:"+confidence);
          
          resultsconcepts += "<ul><li title=\"Premise\">"+premiseWordString+"</li>"
                          +"<li title=\"Conclusion\">"+ conclusionWordString+"</li>"
                          +"<li title=\"Confidence\" class=\"metrics\">"+ confidence+"</li>"
                          +"<li title=\"Conviction\" class=\"metrics\">";
                            
          if ( conviction.toString().contains("8888") )
            resultsconcepts += "Infinity";
          else
            resultsconcepts += conviction;
                    
          resultsconcepts += "</li>"
                          +"<li title=\"Gain\" class=\"metrics\">"+ gain+"</li>"
                          +"<li title=\"Laplace\" class=\"metrics\">"+ laplace+"</li>"
                          +"<li title=\"Lift\" class=\"metrics\">"+ lift+"</li>"
                          +"<li title=\"Ps\" class=\"metrics\">"+ ps+"</li>"
                          +"<li title=\"Total Support\" class=\"metrics\">"+ totalSupport+"</li><li class=\"num_rules\">"+(i+1)+"</li></ul>";
        
          System.out.println("("+(i+1)+")"+" Finish: Premise <"+rulesHM.get(i+1).get(0)+"> Conclusion <"+rulesHM.get(i+1).get(1)+">");            
        }
      }
      else
        System.out.println("There are no rules in database.");
      
      dbRules.databaseDisconnect(con);
      
      Calendar cal2 = Calendar.getInstance(); 
      cal2.getTime(); 
      System.out.println("["+sdf.format(cal2.getTime())+"]");
      Integer time;
      SimpleDateFormat sdf2 = new SimpleDateFormat("HHmmss");
      time = Integer.parseInt( sdf2.format(cal2.getTime()).toString() ) - Integer.parseInt( sdf2.format(cal.getTime()).toString() ) ;
      System.out.println("["+time+"]");
    }
    
    
    /**
     * @return the results
     */
    public String getResults() {
        rapidminerInit();
        processResults();
        return results;
    }

    /**
     * @param aResults the results to set
     */
    public void setResults(String aResults) {
        this.results = aResults;
    }
    
    /**
     * @return the results
     */
    public String getResultsconcepts() {
        //rapidminerInit();
        //processResultsConcepts();
        processResultsFromDatabaseV2();
        return resultsconcepts;
    }

    /**
     * @param aResults the results to set
     */
    public void setResultsconcepts(String aResults) {
        this.resultsconcepts = aResults;
    }
    
    public void setResultsToDatabase(String aResults) {
        this.resultsToDatabase = aResults;
    }

    public String getResultsToDatabase() {
        rapidminerInit();
        processResultsToDatabase();
        return resultsToDatabase;
    }
    


    
           
        
        
}

