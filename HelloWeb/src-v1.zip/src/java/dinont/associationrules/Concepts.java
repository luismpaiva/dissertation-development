/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dinont.associationrules;

import com.rapid_i.repository.wsimport.ProcessContextWrapper;
import java.util.ArrayList;
import java.util.HashMap;
import seks.basic.ontology.OntologyInteractionImpl;
import java.sql.Connection;
import java.sql.*;
import dinont.utilities.Database;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Luis
 */
public class Concepts {
  
  // private static OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
  private static String namespace = ("http://www.knowspaces.com/ontology_v1.owl#");
//  private static ArrayList<String> keywordWithWord = new ArrayList<String> ();
//  private static ArrayList<String> conceptsList = new ArrayList<String> ();

  //private static ArrayList<String> ngramsList = new ArrayList<String> ();

  public Concepts() {
  }
  
  /**
   * 
   * @param word (the n-gram word to evaluate)
   * @return 0 for no matches or the arrayListResult with all matches
   */
  
  public ArrayList<String> getNgramList(String word){
    ArrayList<String> arrayListResult = new ArrayList<String> ();
    ArrayList<String> ngramList = new ArrayList<String> ();
    ArrayList<String> keywordList = new ArrayList<String> ();
    ArrayList<String> allkeywords;
    int equalKeys = 0;
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    
    ngramList = processWord(word, "_");
    
    for (int iterator = 0; iterator<ngramList.size(); iterator++)
      System.out.print("ngram"+iterator+":"+ngramList.get(iterator)+";");
    System.out.print("\n");
    
    allkeywords = oi.getAllValuesFromProperty("has_Keyword");
    
    if (!allkeywords.isEmpty()) 
      for (int i=0;i<allkeywords.size();i++){
        keywordList = processWord(allkeywords.get(i), " ");

        if (ngramList.size() == keywordList.size())
          for (int h=0; h<ngramList.size();h++){
            if ( keywordList.get(h).startsWith(ngramList.get(h)) ){
              equalKeys++;
              System.out.println("keywordList»"+keywordList+"«ngramsList»"+ngramList.get(h)+"«equalKeys:"+equalKeys);
            }
            else
              h = ngramList.size()+999;
          }
          if (equalKeys == ngramList.size()){
            arrayListResult.add(allkeywords.get(i));
            System.out.println("Added: "+allkeywords.get(i));
          }
          equalKeys = 0;
      }
    return arrayListResult;
  }
  
  public int getNGramWordCount (String word) {
    ArrayList<String> xpto = this.processWord(word, " ");
    return xpto.size();
  }
  
  /**
   * When it does not find an exact match, it tries to find candidates for an aproximate match
   * @param word (the n-gram word to evaluate)
   * @return 0 for no approximate matches or the arrayListResult with all candidate matches
   */
  
  public ArrayList<String> getOnegramCandidatesList(String word){
    ArrayList<String> arrayListResult = new ArrayList<String> ();
    ArrayList<String> ngramList = new ArrayList<String> ();
    ArrayList<String> keywordList = new ArrayList<String> ();
    ArrayList<String> allkeywords;
    int equalKeys = 0;
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    
    ngramList = processWord(word, "_");
    
    allkeywords = oi.getAllValuesFromProperty("has_Keyword");
    
    if (!allkeywords.isEmpty()) 
      for (int i=0;i<allkeywords.size();i++){
          keywordList = processWord(allkeywords.get(i), " ");
          if (keywordList.size() <= 3 ) {
            for (int h=0; h<ngramList.size();h++){
              for (int j=0; j<keywordList.size();j++)
                if ( keywordList.get(j).startsWith(ngramList.get(h)) ){
                  equalKeys++;
                  System.out.println("keywordList»"+keywordList+"«ngramsList»"+ngramList.get(h)+"«equalKeys:"+equalKeys);
              }
            }
            if (equalKeys > 0){
              arrayListResult.add(allkeywords.get(i));
              System.out.println("Added: "+allkeywords.get(i));
            }
          }
          equalKeys = 0;
      }
    return arrayListResult;
  }
  
  public HashMap <String, ArrayList<String>> getOnegramCandidatesListV2(String word){
    ArrayList<String> arrayListLevel1Result = new ArrayList<String> ();
    ArrayList<String> arrayListLevel2Result = new ArrayList<String> ();
    ArrayList<String> keywordList = new ArrayList<String> ();
    ArrayList<String> allkeywords;
    HashMap <String, ArrayList<String>> hmResult = new HashMap ();
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    String matchLevel = "";
    boolean matchFlag = false;
    
    allkeywords = oi.getAllValuesFromProperty("has_Keyword");
    
    if (!allkeywords.isEmpty()) 
      for (int i=0;i<allkeywords.size();i++){
          keywordList = processWord(allkeywords.get(i), " ");
          if (keywordList.size() <= 3 ) {
            for (int j=0; j<keywordList.size();j++)
              if ( keywordList.get(j).startsWith(word) ){
                matchFlag = true;
                switch (keywordList.size()) {
                  case 2: {
                      matchLevel = "level1";
                      arrayListLevel1Result.add(allkeywords.get(i));
                      break;
                  }
                  case 3:{
                      matchLevel = "level2";
                      arrayListLevel2Result.add(allkeywords.get(i));
                      break;
                  }
                  default:{
                    break;
                  }
                }
                System.out.println("Added ("+matchLevel+"): <"+allkeywords.get(i) +"> for word «"+word+"»");
              }
          }
          
      }
    if (matchFlag) {
      hmResult.put("level1", arrayListLevel1Result);
      hmResult.put("level2", arrayListLevel2Result);
    }

    return hmResult;
  }
  
  public Integer getComonWords(ArrayList<String> arrayList1, ArrayList<String> arrayList2) {
    int equalKeys = 0;
    for (int h=0; h<arrayList1.size();h++){
                for (int j=0; j<arrayList2.size();j++){
                  if (arrayList2.get(j).startsWith(arrayList1.get(h))){
                    equalKeys++;
                  }
                }
              }
    return equalKeys;
  }
  
  public Double getCosineSimilarity(ArrayList<String> arrayList1, ArrayList<String> arrayList2){
    Double cosSim = (((this.getComonWords(arrayList1, arrayList2).doubleValue())*(this.getComonWords(arrayList1, arrayList2)))/(arrayList1.size()*arrayList2.size()));
    return cosSim;
  }
  
  public HashMap <String, ArrayList<String>> getNgramListV2(String word){
    ArrayList<String> arrayListLevel1Result = new ArrayList<String> ();
    ArrayList<String> arrayListLevel2Result = new ArrayList<String> ();
    ArrayList<String> keywordList = new ArrayList<String> ();
    ArrayList<String> allkeywords;
    HashMap <String, ArrayList<String>> hmResult = new HashMap ();
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    String matchLevel = "";
    boolean matchFlag = false;
    
    allkeywords = oi.getAllValuesFromProperty("has_Keyword");
    
    if (!allkeywords.isEmpty()) 
      for (int i=0;i<allkeywords.size();i++){
          keywordList = processWord(allkeywords.get(i), " ");
          if (keywordList.size() <= 3 ) {
            for (int j=0; j<keywordList.size();j++)
              if ( keywordList.get(j).startsWith(word) ){
                matchFlag = true;
                switch (keywordList.size()) {
                  case 2: {
                      matchLevel = "level1";
                      arrayListLevel1Result.add(allkeywords.get(i));
                      break;
                  }
                  case 3:{
                      matchLevel = "level2";
                      arrayListLevel2Result.add(allkeywords.get(i));
                      break;
                  }
                  default:{
                    break;
                  }
                }
                System.out.println("Added ("+matchLevel+"): <"+allkeywords.get(i) +"> for word «"+word+"»");
              }
          }
          
      }
    if (matchFlag) {
      hmResult.put("level1", arrayListLevel1Result);
      hmResult.put("level2", arrayListLevel2Result);
    }

    return hmResult;
  }
  
  public HashMap <String, ArrayList<String>> getBigramCandidatesList(String word){
    HashMap <String, ArrayList<String>> levelCandidates = new HashMap<String, ArrayList<String>>();
    ArrayList<String> level0 = new ArrayList<String> ();
    ArrayList<String> level1 = new ArrayList<String> ();
    ArrayList<String> level2 = new ArrayList<String> ();
    ArrayList<String> level3 = new ArrayList<String> ();
    ArrayList<String> level4 = new ArrayList<String> ();
    ArrayList<String> level5 = new ArrayList<String> ();
    ArrayList<String> ngramList;
    ArrayList<String> keywordList;
    ArrayList<String> allkeywords;

    int equalKeys = 0;
    int level = 6;
    String sourceWord;
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    
    ngramList = processWord(word, "_");
    
    allkeywords = oi.getAllValuesFromProperty("has_Keyword");
  
    // 80% compare bi-gram with tri-gram - level1
    // 60% compare bi-gram with trigram (partitioned trigrams) - level2
    // 40% compare bi-gram with bi-gram (one word in common) - level3
    // 20% compare bi-gram with tri-gram (one word in common) - level4
    // 5% compare bi-gram with uni-gram (one word in common) - level5
  
    if (!allkeywords.isEmpty()) {
      for (int i=0;i<allkeywords.size();i++){
          keywordList = processWord(allkeywords.get(i), " ");
          level = 0;
          equalKeys = 0;
          if (keywordList.size() == 3 ) {
            if ((keywordList.get(0).startsWith(ngramList.get(0)))&& (keywordList.get(1).startsWith(ngramList.get(1)))){
              level = 1;
              level1.add(allkeywords.get(i));
            } else if ((keywordList.get(0).startsWith(ngramList.get(0)))&& (keywordList.get(1).startsWith(ngramList.get(1)))){
              level = 1;
              level1.add(allkeywords.get(i));
            } else {
              for (int h=0; h<ngramList.size();h++){
                for (int j=0; j<keywordList.size();j++){
                  if (keywordList.get(j).startsWith(ngramList.get(h))){
                    equalKeys++;
                  }
                }
              }
              if (equalKeys == 1){
                level = 4;
                level4.add(allkeywords.get(i));
              } else if (equalKeys == 2){
                  level = 2;
                  level2.add(allkeywords.get(i));
                }
            }
            
          } else if (keywordList.size() == 2 ) {
              for (int h=0; h<ngramList.size();h++){
                for (int j=0; j<keywordList.size();j++){
                  if (keywordList.get(j).startsWith(ngramList.get(h)))
                    equalKeys++;
                }
              } 
              if (equalKeys == 1){
                level = 3;
                level3.add(allkeywords.get(i));
              }
              if ((equalKeys == 2) && (keywordList.get(0).startsWith(ngramList.get(0)))) {
                level = 0;
                level0.add(allkeywords.get(i));
              }
            
            } else if (keywordList.size() == 1){
                for (int h=0; h<ngramList.size();h++){
                  for (int j=0; j<keywordList.size();j++){
                    if (keywordList.get(j).startsWith(ngramList.get(h)))
                      equalKeys++;
                  }
                }
                if (equalKeys == 1){
                  level = 5;
                  level5.add(allkeywords.get(i));
                }
             }
      }
    }
    else {System.out.println("Allkeywords is empty");}
    
    levelCandidates.put("level0", level0);
    levelCandidates.put("level1", level1);
    levelCandidates.put("level2", level2);
    levelCandidates.put("level3", level3);
    levelCandidates.put("level4", level4);
    levelCandidates.put("level5", level5);
    
    return levelCandidates;
  }
  
  public ArrayList<String> processWord(String wordProcessing, String separator)
  {
    ArrayList<String> arrayListResult = new ArrayList<String> ();
    int underscorePos;
    
    while (wordProcessing.contains(separator)){
      underscorePos = wordProcessing.indexOf(separator);
      arrayListResult.add(wordProcessing.substring(0, underscorePos));
      wordProcessing = wordProcessing.substring(underscorePos+1);
    }
    
    arrayListResult.add(wordProcessing);  
    
    return arrayListResult;
  }
  
  public HashMap<String, ArrayList<String>> getConceptsRelated(ArrayList<String> wordList){
    HashMap<String,ArrayList<String>> conceptsList = new HashMap<String,ArrayList<String>> ();
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    
    if (!wordList.isEmpty())
      for (int i=0;i<wordList.size();i++)
        conceptsList.put(wordList.get(i), oi.getSubjectsFromProperty(wordList.get(i), "has_Keyword"));

    return conceptsList;
  }
  
  public HashMap<String, ArrayList<String>> getAllConceptsRelated(String word){
    
    return getConceptsRelated(getNgramList(word));
  }
  
  public String getClassColorConceptsName (int classNumber){
    String ngramsMatchColorClass = "";
                        switch (classNumber) {
                          case 0:ngramsMatchColorClass = "level0";
                            break;
                          case 1:ngramsMatchColorClass = "level1";
                            break;
                          case 2:ngramsMatchColorClass = "level2";
                            break;
                          case 3:ngramsMatchColorClass = "level3";
                            break;
                          case 4:ngramsMatchColorClass = "level4";
                            break;
                          default:ngramsMatchColorClass = "level5";
                            break;
                        }
    return ngramsMatchColorClass;
  }
  
  
  public static void main(String[] args){
    
    // TEST AREA BELOW
    
    HashMap<String,ArrayList<String>> allConceptsList = new HashMap<String,ArrayList<String>> ();
    HashMap<String,ArrayList<String>> allConceptsUnigramsList = new HashMap<String,ArrayList<String>> ();
    HashMap<String,ArrayList<String>> levelCandidates = new HashMap<String,ArrayList<String>> ();
    HashMap<Integer,ArrayList<String>> testHM = new HashMap<Integer,ArrayList<String>> ();
    OntologyInteractionImpl oi = new OntologyInteractionImpl() ;
    ArrayList<String> allkeywords2;
    allkeywords2 = oi.getAllValuesFromProperty("has_Keyword");
    Concepts cp = new Concepts();
    ArrayList<String> ngramsCandidates = new ArrayList<String> ();
    
    String word = "energ_consumpt_wast";
    String word2 = "energy consumption waste";
    String word3 = "energy waste consumption";
    String word4 = "waste energy consumption";
    String word5 = "waste waste energy";
    
    String matchPercentage = "";
    for (int abc=0; abc<allkeywords2.size(); abc++)
      if ((allkeywords2.get(abc).contains("energi")) && (cp.processWord(allkeywords2.get(abc), " ").size() <=3))
        System.out.println(""+allkeywords2.get(abc));
    
    levelCandidates = cp.getBigramCandidatesList(word);
    
    if (!levelCandidates.isEmpty()){
      for (int i=0; i<levelCandidates.size(); i++){
        switch (i) {
            case 0: {
              ngramsCandidates = levelCandidates.get("level0");
              matchPercentage = "Level 0 [100.0%]";
              break;
            }
            case 1:{
              ngramsCandidates = levelCandidates.get("level1");
              matchPercentage = "Level 1 [80.0%]";
              break;
            }
            case 2:{
              ngramsCandidates = levelCandidates.get("level2");
              matchPercentage = "Level 2 [60.0%]";
              break;
            }
            case 3:{
              ngramsCandidates = levelCandidates.get("level3");
              matchPercentage = "Level 3 [40.0%]";
              break;
            }
            case 4:{
              ngramsCandidates = levelCandidates.get("level4");
              matchPercentage = "Level 4 [20.0%]";
              break;
            }
            case 5:{
              ngramsCandidates = levelCandidates.get("level5");
              matchPercentage = "Level 5 [5.0%]";
              break;
            }
            default:{
              ngramsCandidates.add("Empty");
              matchPercentage = "0";
              break;
            }
          }
          System.out.println("<"+matchPercentage+"> "+ngramsCandidates.size()+" Candidates:");
          for (int j=0; j<ngramsCandidates.size(); j++) {
            System.out.print("<"+ngramsCandidates.get(j)+">");
          }
          System.out.println();
        }
        ngramsCandidates = new ArrayList<String>();
      }
      else{
        System.out.println("NoCandidates found");
      }
    
    // ------- Connection to database functions below!!! 
    Integer i2 = cp.getComonWords(cp.processWord(word, "_"), cp.processWord(word2, " "));
    Integer i3 = cp.getComonWords(cp.processWord(word, "_"), cp.processWord(word3, " "));
    Integer i4 = cp.getComonWords(cp.processWord(word, "_"), cp.processWord(word4, " "));
    Integer i5 = cp.getComonWords(cp.processWord(word, "_"), cp.processWord(word5, " "));
    
    Double d2 = cp.getCosineSimilarity(cp.processWord(word, "_"), cp.processWord(word2, " "))*100;
    Double d3 = cp.getCosineSimilarity(cp.processWord(word, "_"), cp.processWord(word3, " "))*100;
    Double d4 = cp.getCosineSimilarity(cp.processWord(word, "_"), cp.processWord(word4, " "))*100;
    Double d5 = cp.getCosineSimilarity(cp.processWord(word, "_"), cp.processWord(word5, " "))*100;

    if (d2 == 100.0) {
        System.out.println("d2"+d2);
       if (!cp.processWord(word2, " ").get(0).startsWith(cp.processWord(word, "_").get(0)))
          d2 -= 1;
       if (!cp.processWord(word2, " ").get(1).startsWith(cp.processWord(word, "_").get(1)))
          d2 -= 1;
       if (!cp.processWord(word2, " ").get(2).startsWith(cp.processWord(word, "_").get(2)))
          d2 -= 1;
    }
     
    if (d3 == 100.0) {
       if (!cp.processWord(word3, " ").get(0).startsWith(cp.processWord(word, "_").get(0)))
          d3 -= 1;
       if (!cp.processWord(word3, " ").get(1).startsWith(cp.processWord(word, "_").get(1)))
          d3 -= 1;
       if (!cp.processWord(word3, " ").get(2).startsWith(cp.processWord(word, "_").get(2)))
          d3 -= 1;
    }
     
    if (d4 == 100.0) {
       if (!cp.processWord(word4, " ").get(0).startsWith(cp.processWord(word, "_").get(0)))
          d4 -= 1;
       if (!cp.processWord(word4, " ").get(1).startsWith(cp.processWord(word, "_").get(1)))
          d4 -= 1;
       if (!cp.processWord(word4, " ").get(2).startsWith(cp.processWord(word, "_").get(2)))
          d4 -= 1;
    }
     
    if (d5 == 100.0) {
       if (!cp.processWord(word5, " ").get(0).startsWith(cp.processWord(word, "_").get(0)))
          d5 -= 1;
       if (!cp.processWord(word5, " ").get(1).startsWith(cp.processWord(word, "_").get(1)))
          d5 -= 1;
       if (!cp.processWord(word5, " ").get(2).startsWith(cp.processWord(word, "_").get(2)))
          d5 -= 1;
    }
     
    System.out.println("Common words between <"+word+"> and <"+word2+"> - "+i2+". And Cosine Similarity is "+d2);
    System.out.println("Common words between <"+word+"> and <"+word3+"> - "+i3+". And Cosine Similarity is "+d3);
    System.out.println("Common words between <"+word+"> and <"+word4+"> - "+i4+". And Cosine Similarity is "+d4);
    System.out.println("Common words between <"+word+"> and <"+word5+"> - "+i5+". And Cosine Similarity is "+d5);
    
    System.out.println("Common words between <"+word+"> and <"+word2+"> - "+i2+". And Cosine Similarity is "+String.format("%3.0f %n", d2));
    
    System.out.println("Common words between <"+word+"> and <"+word3+"> - "+i3+". And Cosine Similarity is "+String.format("%3.0f %n", d3));
    
    System.out.println("Common words between <"+word+"> and <"+word4+"> - "+i4+". And Cosine Similarity is "+String.format("%3.0f %n", d4));
    
    System.out.println("Common words between <"+word+"> and <"+word5+"> - "+i5+". And Cosine Similarity is "+String.format("%3.0f %n", d5));
    
    Connection con;
    Database db = new Database();
    con = db.databaseConnect("jdbc:mysql://localhost:3306/mydb", "root", "", "com.mysql.jdbc.Driver");
    //String sqlQuery = "SELECT * FROM stemmed_word";
    //String[] values = {"xpto"};
    //String query = "INSERT INTO stemmed_word(idstemmed_word, stemmed_word) values(?, ?)";
    //db.databaseInsertOneDataRecord(con, query, 2, values);
    
    //int id = db.databaseRecordID(con, "stemmed_word", "idstemmed_word", word, "stemmed_word");
    /*ArrayList<String> wordAL = new ArrayList<String>();
     * String num = "1";
     * wordAL.add(0, "");
     * wordAL.add(1, word);
     * wordAL.add(2, word);
     * wordAL.add(3, num);
     * wordAL.add(4, num);
     * wordAL.add(5, num);
     * wordAL.add(6, num);
     * wordAL.add(7, num);
     * wordAL.add(8, num);*/
    
//    db.databaseInsertRule(con, wordAL);
//    db.databaseInsertRule(con, wordAL);
//    db.databaseInsertRule(con, wordAL);
    
    //db.databaseInsertRule(con, word);
    //db.databaseSelectData(con, sqlQuery);

    //db.databaseDeleteAllRecordsFromTable(con, "stemmed_word");
    // db.databaseDeleteAllRecordsFromTable(con, "rules_stemmed");

    //db.databaseSelectData(con, sqlQuery);
    //testHM = db.databaseGetRules(con);
    //db.databaseDisconnect(con);
    
    }
}
